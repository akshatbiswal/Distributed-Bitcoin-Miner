// Contains the implementation of a LSP client.

package lsp

import (
	"encoding/json"
	"errors"
	"github.com/cmu440/lspnet"
	"time"
)

type client struct {
	// connection, params
	conn       *lspnet.UDPConn
	serverAddr *lspnet.UDPAddr
	params     *Params

	// ids & seq nums
	connID      int
	isn         int
	nextSendSeq int
	nextRecvSeq int

	// send-side state (sliding window)
	windowSize int
	maxUnacked int
	inflight   map[int]*Message
	sendQ      [][]byte

	// recv-side state
	recvBuf   map[int][]byte
	deliverQ  [][]byte
	appReadCh chan []byte

	// app -> client
	appWriteCh chan []byte
	closeReq   chan struct{}
	closed     chan error

	// internal events
	netInCh     chan Message
	connAckCh   chan struct{}
	stopped     chan struct{}
	readStopped chan struct{}

	// epochs
	epochTickCh        chan struct{}
	stopEpochCh        chan struct{}
	epochsSinceRecv    int
	sentSinceLastEpoch bool
	connectEpochs      int
	backoff            map[int]*backoffState
	connErrCh          chan error

	// state to deal with server slow start
	serverStart bool
}

type backoffState struct {
	currentBackoff int
	remaining      int
}

// NewClient creates, initiates, and returns a new client. This function
// should return after a connection with the server has been established
// (i.e., the client has received an Ack message from the server in response
// to its connection request), and should return a non-nil error if a
// connection could not be made (i.e., if after K epochs, the client still
// hasn't received an Ack message from the server in response to its K
// connection requests).
//
// initialSeqNum is an int representing the Initial Sequence Number (ISN) this
// client must use. You may assume that sequence numbers do not wrap around.
//
// hostport is a colon-separated string identifying the server's host address
// and port number (i.e., "localhost:9999").
func NewClient(hostport string, initialSeqNum int, params *Params) (Client, error) {
	raddr, err := lspnet.ResolveUDPAddr("udp", hostport)
	if err != nil {
		return nil, err
	}
	conn, err := lspnet.DialUDP("udp", nil, raddr)
	if err != nil {
		return nil, err
	}
	if params == nil {
		params = NewParams()
	}
	c := &client{
		conn:               conn,
		serverAddr:         raddr,
		params:             params,
		isn:                initialSeqNum,
		nextSendSeq:        initialSeqNum + 1,
		windowSize:         params.WindowSize,
		maxUnacked:         params.MaxUnackedMessages,
		inflight:           make(map[int]*Message),
		sendQ:              make([][]byte, 0),
		recvBuf:            make(map[int][]byte),
		deliverQ:           make([][]byte, 0),
		appReadCh:          make(chan []byte),
		appWriteCh:         make(chan []byte),
		closeReq:           make(chan struct{}),
		closed:             make(chan error, 1),
		netInCh:            make(chan Message, 1),
		connAckCh:          make(chan struct{}, 1),
		stopped:            make(chan struct{}),
		readStopped:        make(chan struct{}),
		epochTickCh:        make(chan struct{}, 1),
		stopEpochCh:        make(chan struct{}),
		epochsSinceRecv:    0,
		sentSinceLastEpoch: false,
		connectEpochs:      0,
		backoff:            make(map[int]*backoffState),
		connErrCh:          make(chan error, 1),
		serverStart:        false,
	}

	// start goroutines
	go c.readLoop()
	go c.mainLoop()
	go c.startEpochTimer()
	if err := c.sendConnect(); err != nil {
		_ = c.conn.Close()
		return nil, err
	}

	select {
	case <-c.connAckCh:
		// This deals with the server slow start case
		c.serverStart = true
		return c, nil
	case err := <-c.connErrCh:
		_ = c.conn.Close()
		return nil, err
	}
}

func (c *client) ConnID() int {
	return c.connID
}

// This function is application facing and returns in order reads fron the server
func (c *client) Read() ([]byte, error) {
	select {
	// appReadCh is the final deistanation for in order messages from server
	case p := <-c.appReadCh:
		return p, nil
	case <-c.stopped:
		return nil, errors.New("client closed")
	}
}

// This function is application facting and sends whatever payloads is given
func (c *client) Write(payload []byte) error {
	p := append([]byte(nil), payload...)
	select {
	// We write the message to appWriteCh
	case c.appWriteCh <- p:
		return nil
	case <-c.stopped:
		return errors.New("client closed")
	}
}

// This function is application facing and begins the closing process by updating the
// closeReq channel and then waits on stopped and closed, which are updated by the read
// write, and epochTimer goroutines
func (c *client) Close() error {
	select {
	case c.closeReq <- struct{}{}:
	case <-c.stopped:
	}
	err := <-c.closed
	return err
}

func (c *client) sendConnect() error {
	msg := NewConnect(c.isn)
	return c.sendMsg(msg)
}

func (c *client) sendAck(seq int) {
	if c.connID == 0 {
		return
	}
	_ = c.sendMsg(NewAck(c.connID, seq))
}

// This helper function will send a payload with a specific sequence number
// by calculating the checksum, then making it a message type of data, and then
// update inflight and backoff state maps
func (c *client) sendData(seq int, p []byte) error {
	if c.connID == 0 {
		return errors.New("no connID")
	}
	cs := CalculateChecksum(c.connID, seq, len(p), p)
	msg := NewData(c.connID, seq, len(p), p, cs)
	if err := c.sendMsg(msg); err != nil {
		return err
	}
	c.inflight[seq] = msg
	if _, ok := c.backoff[seq]; !ok {
		c.backoff[seq] = &backoffState{currentBackoff: 0, remaining: 0}
	}
	c.sentSinceLastEpoch = true
	return nil
}

// This function sends a message by marchalling it and then writting it to the socket
func (c *client) sendMsg(m *Message) error {
	b, err := json.Marshal(m)
	if err != nil {
		return err
	}
	_, err = c.conn.Write(b)
	return err
}

// This function uses the inflight map to get the massage with the lowest
// sequence number that is still inflight
func (c *client) oldestUnacked() (int, bool) {
	min := 0
	first := true
	for seq := range c.inflight {
		if first || seq < min {
			min = seq
			first = false
		}
	}
	return min, !first
}

// Usses the window size and maxUnacked to determie if any more messages
// can be sent at this moment
func (c *client) canSendMore() bool {
	if len(c.inflight) >= c.maxUnacked {
		return false
	}
	//making sure we don't go too far past the oldest unacked
	if base, ok := c.oldestUnacked(); ok {
		if c.nextSendSeq-base >= c.windowSize {
			return false
		}
	}
	return true
}

// Trys to send any messages that are in the sendA
func (c *client) tryDrainSends() {
	for c.connID != 0 && c.canSendMore() && len(c.sendQ) > 0 {
		seq := c.nextSendSeq
		p := c.sendQ[0]
		_ = c.sendData(seq, p)
		c.sendQ = c.sendQ[1:]
		c.nextSendSeq++
	}
}

// Takes a message(ack, Cack, and data), and updates any buffers/maps, but
// doesn't do any acutal sending.
func (c *client) processIncoming(m Message) {
	c.epochsSinceRecv = 0

	switch m.Type {
	case MsgAck:
		// If this is the server ack for connecting to the server
		// the connId will be 0, and the seqnum will be whatever the
		// intial ism is
		if c.connID == 0 && m.SeqNum == c.isn {
			c.connID = m.ConnID
			c.nextRecvSeq = m.SeqNum + 1
			select {
			case c.connAckCh <- struct{}{}:
			default:
			}
			return
		}
		// remove the seq number from the sending state
		delete(c.inflight, m.SeqNum)
		delete(c.backoff, m.SeqNum)

	case MsgCAck:
		// Same idea as above but loop through all inflight messages
		for s := range c.inflight {
			if s <= m.SeqNum {
				delete(c.inflight, s)
				delete(c.backoff, s)
			}
		}

	case MsgData:
		// It puts payload into deliverQ is possible otherwise recvBuf
		if m.Size < 0 {
			return
		}
		// Based on specifications of the architecture since a payload that
		// has a size less than the given size is corrupt, if the payload
		// size is greater than the given size then we just truncate it
		if len(m.Payload) < m.Size {
			return
		}
		if len(m.Payload) > m.Size {
			m.Payload = m.Payload[:m.Size]
		}
		if CalculateChecksum(c.connID, m.SeqNum, m.Size, m.Payload) != m.Checksum {
			return
		}
		if c.nextRecvSeq == 0 {
			c.nextRecvSeq = m.SeqNum
		}
		// Already recieved the data assocaited with this seq num
		if m.SeqNum < c.nextRecvSeq {
			c.sendAck(m.SeqNum)
			return
		}
		if m.SeqNum == c.nextRecvSeq {
			c.deliverQ = append(c.deliverQ, m.Payload)
			c.sendAck(m.SeqNum)
			c.nextRecvSeq++
			for {
				// The recvBuf has all greater seq numbers
				p, ok := c.recvBuf[c.nextRecvSeq]
				if !ok {
					break
				}
				delete(c.recvBuf, c.nextRecvSeq)
				c.deliverQ = append(c.deliverQ, p)
				c.sendAck(c.nextRecvSeq)
				c.nextRecvSeq++
			}
			return
		}
		c.recvBuf[m.SeqNum] = m.Payload
		c.sendAck(m.SeqNum)
	}
}

// Most of the state changes happen in the main loop
// all other loops sends things to the main loop and the
// main loop process all the requests
func (c *client) mainLoop() {
	defer func() {
		close(c.stopped)
	}()

	var outCh chan []byte
	var outNext []byte
	closing := false

	for {
		// Try to put the whatever is in the deliverQ into
		// the appReadCh which is what is read by application
		if len(c.deliverQ) > 0 {
			outCh = c.appReadCh
			outNext = c.deliverQ[0]
		} else {
			outCh = nil
			outNext = nil
		}

		c.tryDrainSends()

		if closing && len(c.sendQ) == 0 && len(c.inflight) == 0 {
			_ = c.conn.Close()
			<-c.readStopped
			c.closed <- nil
			return
		}

		select {
		// We can put anything from write into SendQ
		case p := <-c.appWriteCh:
			c.sendQ = append(c.sendQ, p)

		case m := <-c.netInCh:
			c.processIncoming(m)
		// Try to put first element of deliverQ in deliverQ
		case outCh <- outNext:
			c.deliverQ = c.deliverQ[1:]

		case <-c.closeReq:
			closing = true

		case <-c.epochTickCh:
			if c.connID == 0 {
				// We are still trying to connect
				_ = c.sendConnect()
				c.connectEpochs++
				if c.connectEpochs >= c.params.EpochLimit {
					select {
					case c.connErrCh <- errors.New("connection timed out"):
					default:
					}
					return
				}
			} else {
				// handle epoch returns true when we need to close
				// the goroutine because the server is not responding
				if c.handleEpoch() {
					return
				}
			}
		}
	}
}

// healper function for the main loop
// deals with exponential backoff and when nothing is sent from the server
// if will return true when the server is presumed dead
func (c *client) handleEpoch() bool {
	resendHappened := false
	for seq, msg := range c.inflight {
		st := c.backoff[seq]
		if st == nil {
			st = &backoffState{currentBackoff: 0, remaining: 0}
			c.backoff[seq] = st
		}
		if st.remaining > 0 {
			st.remaining--
			continue
		}
		// We are at the epoch when we need to send an ack
		_ = c.sendMsg(msg)
		resendHappened = true
		// changing backoff to 2*oldbackoff unless 0 because 0*2=0
		if st.currentBackoff == 0 {
			st.currentBackoff = 1
		} else {
			st.currentBackoff *= 2
			if st.currentBackoff > c.params.MaxBackOffInterval {
				st.currentBackoff = c.params.MaxBackOffInterval
			}
		}
		st.remaining = st.currentBackoff
	}
	// Only send ack if we havn't sent anything
	if !c.sentSinceLastEpoch && !resendHappened {
		if c.connID != 0 {
			_ = c.sendMsg(NewAck(c.connID, 0))
		}
	}
	c.epochsSinceRecv++
	// close evverything assocated with the epoch ticker
	if c.epochsSinceRecv >= c.params.EpochLimit {
		_ = c.conn.Close()
		<-c.readStopped
		close(c.stopEpochCh)
		c.closed <- errors.New("epoch timeout")
		return true
	}
	c.sentSinceLastEpoch = false
	return false
}

// Waits for data from the server, and just unmarshals it
// and puts it into the netInCh channell for the main loop
func (c *client) readLoop() {
	defer close(c.readStopped)
	udpBufSize := 65507
	buf := make([]byte, udpBufSize)
	// Read, unmarshal, and then send the message
	for {
		n, err := c.conn.Read(buf)
		if err != nil {
			if !c.serverStart {
				continue
			}
			return
		}
		var m Message
		if err := json.Unmarshal(buf[:n], &m); err != nil {
			continue
		}
		select {
		case c.netInCh <- m:
		case <-c.stopped:
			return
		}
	}
}

// This function uses the go time libary to start a ticker
// and it just updates a channel whenever a tick comes from another channel
// and stops whenver one of the stop channels has something put into it
func (c *client) startEpochTimer() {
	t := time.NewTicker(time.Duration(c.params.EpochMillis) * time.Millisecond)
	defer t.Stop()
	for {
		select {
		case <-t.C:
			select {
			case c.epochTickCh <- struct{}{}:
			default:
			}
		case <-c.stopEpochCh:
			return
		case <-c.stopped:
			return
		}
	}
}
